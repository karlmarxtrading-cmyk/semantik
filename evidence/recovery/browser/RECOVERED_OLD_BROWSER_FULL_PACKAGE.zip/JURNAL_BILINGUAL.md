# CP20\_VECTOR\_ONLY\_FIGURES — Sumber & Terjemahan

**Berkas sumber:** CP20\_VECTOR\_ONLY\_FIGURES.pdf
**Halaman:** 3
**Bahasa:** en → id
**Status:** Pemrosesan selesai; perlu peninjauan ilmiah 
**Bagian:** 9 diterjemahkan; 0 dipertahankan sengaja; 0 ditolak; 0 gagal; 0 belum diproses. Total 9.
**Rilis eksportir:** cp20-2e4d8ef18eb32385 · 0.20.0.
**Metode:** ekstraksi PDF/OCR dan terjemahan mesin lokal. Tidak ada klaim verifikasi semantik menyeluruh.

**SHA-256 PDF sumber:** e67819ed4cb4f9fafd7c5757c6008fb9da71dd80010c71aa440cc39c551aa224

PDF asli dan aset visual yang tersedia disertakan dalam paket ini.

<!-- halaman: 1 -->

<!-- bagian: p0001-b0001 | halaman: 1 -->

**Sumber**

### Vector scientific figure: filled-only-bars

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

### Figur ilmiah Vektor: hanya-isi-bar

<!-- bagian: p0001-b0002 | halaman: 1 -->

**Sumber**

This figure contains measurements whose graphical relationship must be retained.

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

Angka ini berisi pengukuran yang hubungan grafisnya harus dipertahankan.

<!-- bagian: p0001-b0003 | halaman: 1 -->

**Sumber**

The source diagram remains essential even when every label is readable.

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

Diagram sumber tetap penting bahkan ketika setiap label dibaca.

#### Citra sumber — halaman 1

![Halaman sumber 1](assets/halaman-0001.jpg)


<!-- halaman: 2 -->

<!-- bagian: p0002-b0001 | halaman: 2 -->

**Sumber**

### Vector scientific figure: stroked-vector-curve

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

### Figur ilmiah Vektor: pengerukan-vektor-curve

<!-- bagian: p0002-b0002 | halaman: 2 -->

**Sumber**

This figure contains measurements whose graphical relationship must be retained.

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

Angka ini berisi pengukuran yang hubungan grafisnya harus dipertahankan.

<!-- bagian: p0002-b0003 | halaman: 2 -->

**Sumber**

The source diagram remains essential even when every label is readable.

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

Diagram sumber tetap penting bahkan ketika setiap label dibaca.

#### Citra sumber — halaman 2

![Halaman sumber 2](assets/halaman-0002.jpg)


<!-- halaman: 3 -->

<!-- bagian: p0003-b0001 | halaman: 3 -->

**Sumber**

### Vector scientific figure: shading-only-gradient

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

### Figur ilmiah Vector: saching-only-gradient

<!-- bagian: p0003-b0002 | halaman: 3 -->

**Sumber**

This figure contains measurements whose graphical relationship must be retained.

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

Angka ini berisi pengukuran yang hubungan grafisnya harus dipertahankan.

<!-- bagian: p0003-b0003 | halaman: 3 -->

**Sumber**

The source diagram remains essential even when every label is readable.

**Terjemahan / hasil**

> Hasil ini dipulihkan dari rilis cp20-8c643bea6962471f; bukan inferensi baru pada rilis eksportir.

Diagram sumber tetap penting bahkan ketika setiap label dibaca.

#### Citra sumber — halaman 3

![Halaman sumber 3](assets/halaman-0003.jpg)


## Catatan pembacaan

- Ruang browser diprioritaskan untuk dokumen dan hasil Anda. Salinan model unduhan telah dihapus; mesin yang sudah dimuat tetap berjalan pada sesi ini. Offline belum siap. Setelah menutup tab, hubungkan jaringan untuk memuat model kembali.

---

Dibuat dengan Semantik Setara — Academic PDF Translator. Teks sumber, hasil mesin, dan koreksi pengguna dipisahkan secara eksplisit.
