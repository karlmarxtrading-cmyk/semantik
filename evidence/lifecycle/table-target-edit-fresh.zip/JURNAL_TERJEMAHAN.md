# table-edit-fixture — Terjemahan

**Berkas sumber:** table-edit-fixture.pdf
**Halaman:** 1
**Bahasa:** belum ditetapkan → belum ditetapkan
**Status:** Pemrosesan selesai; perlu peninjauan ilmiah 
**Bagian:** 1 diterjemahkan; 0 dipertahankan sengaja; 0 ditolak; 0 gagal; 0 belum diproses. Total 1.
**Rilis eksportir:** cp20-development · 0.20.0.
**Metode:** ekstraksi PDF/OCR dan terjemahan mesin lokal. Tidak ada klaim verifikasi semantik menyeluruh.

**SHA-256 PDF sumber:** 02b25b90b3a660af5ba3cc2835a41fe20bcf95e0c5ac368b6cabf0ec4026cf02

PDF asli dan aset visual yang tersedia disertakan dalam paket ini.

<!-- halaman: 1 -->

<!-- bagian: p1-table | halaman: 1 -->

> Hasil ini dipulihkan dari rilis cp18-test; bukan inferensi baru pada rilis eksportir.
> Hasil diedit pengguna.
> Tabel hasil diedit sebagai teks; susunan sel perlu dicocokkan dengan tabel sumber.

```text
Group | Dose
A | 20 mg
Formula | |𝑥| < 1
```


---

Dibuat dengan Semantik Setara — Academic PDF Translator. Teks sumber, hasil mesin, dan koreksi pengguna dipisahkan secara eksplisit.
