# table-edit-fixture — Ekstraksi Sumber

**Berkas sumber:** table-edit-fixture.pdf
**Halaman:** 1
**Bahasa:** id → en
**Status:** Pemrosesan selesai; perlu peninjauan ilmiah 
**Bagian:** 1 diterjemahkan; 0 dipertahankan sengaja; 0 ditolak; 0 gagal; 0 belum diproses. Total 1.
**Rilis eksportir:** cp20-development · 0.20.0.
**Metode:** ekstraksi PDF/OCR dan terjemahan mesin lokal. Tidak ada klaim verifikasi semantik menyeluruh.

**SHA-256 PDF sumber:** 02b25b90b3a660af5ba3cc2835a41fe20bcf95e0c5ac368b6cabf0ec4026cf02

PDF asli dan aset visual yang tersedia disertakan dalam paket ini.

<!-- halaman: 1 -->

<!-- bagian: p1-table | halaman: 1 -->

> Bagian ini memiliki koreksi sumber oleh pengguna pada 2026-11-13T07:43:38.541Z. Dokumen ini mempertahankan ekstraksi asli; sumber terkoreksi ditampilkan dalam dokumen bilingual.

```text
Kelompok | Dosis
A | 10 mg
Rumus | |𝑥| < 1
```


---

Dibuat dengan Semantik Setara — Academic PDF Translator. Teks sumber, hasil mesin, dan koreksi pengguna dipisahkan secara eksplisit.
