# CATATAN PEMERIKSAAN JURNAL

Berkas: CP20\_VECTOR\_ONLY\_FIGURES.pdf

- Status pekerjaan: complete.
- Halaman terdata: 3/3.
- Bagian sumber: 9.
- Diterjemahkan: 9; dipertahankan sengaja: 0; ditolak: 0; gagal: 0; belum diproses: 0.
- Rilis: cp20-2e4d8ef18eb32385; hash source build: 2e4d8ef18eb323855ec23d4f3e16bb1ccd50604065c7afb1e84ff5331f521e79.
- SHA-256 PDF sumber: e67819ed4cb4f9fafd7c5757c6008fb9da71dd80010c71aa440cc39c551aa224.
- Bagian dengan catatan atau belum diproses: 0.
- Bagian dengan koreksi sumber oleh pengguna: 0.
- Item teks ekstraksi yang terlacak: 9 / 9.
- Verifikasi semantik manusia: TIDAK DILAKUKAN OLEH APLIKASI.
- Pemeriksaan otomatis menilai beberapa invariansi struktur, angka, dan identitas ilmiah. Lulus pemeriksaan tidak membuktikan semua makna ilmiah benar.
- Struktur rumus yang didukung diekspor sebagai LaTeX; struktur yang tidak andal diberi label belum terverifikasi dan citra sumber.
- Citra halaman yang berhasil dibaca disertakan dalam paket ZIP. PDF asli memungkinkan pemeriksaan ulang bagian visual dan susunan.

## Pemeriksaan per bagian

### p0001-b0001 — halaman 1

- Jenis: heading.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0001-b0002 — halaman 1

- Jenis: paragraph.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0001-b0003 — halaman 1

- Jenis: paragraph.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0002-b0001 — halaman 2

- Jenis: heading.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0002-b0002 — halaman 2

- Jenis: paragraph.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0002-b0003 — halaman 2

- Jenis: paragraph.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0003-b0001 — halaman 3

- Jenis: heading.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0003-b0002 — halaman 3

- Jenis: paragraph.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

### p0003-b0003 — halaman 3

- Jenis: paragraph.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Kategori hasil: translated; dapat dicoba ulang: tidak.

## Catatan halaman

- Ruang browser diprioritaskan untuk dokumen dan hasil Anda. Salinan model unduhan telah dihapus; mesin yang sudah dimuat tetap berjalan pada sesi ini. Offline belum siap. Setelah menutup tab, hubungkan jaringan untuk memuat model kembali.
