# CATATAN PEMERIKSAAN JURNAL

Berkas: fixture.pdf

- Status pekerjaan: complete.
- Halaman terdata: 1/1.
- Bagian sumber: 4.
- Diterjemahkan: 2; dipertahankan sengaja: 1; ditolak: 1; gagal: 0; belum diproses: 0.
- Rilis: cp20-development; hash source build: development.
- SHA-256 PDF sumber: 304bea89eb8c2f2142c42d3cb4f0527d1cee3465d5ea737944361e786d46ea10.
- Bagian dengan catatan atau belum diproses: 2.
- Bagian dengan koreksi sumber oleh pengguna: 1.
- Item teks ekstraksi yang terlacak: ? / ?.
- Verifikasi semantik manusia: TIDAK DILAKUKAN OLEH APLIKASI.
- Pemeriksaan otomatis menilai beberapa invariansi struktur, angka, dan identitas ilmiah. Lulus pemeriksaan tidak membuktikan semua makna ilmiah benar.
- Struktur rumus yang didukung diekspor sebagai LaTeX; struktur yang tidak andal diberi label belum terverifikasi dan citra sumber.
- Citra halaman yang berhasil dibaca disertakan dalam paket ZIP. PDF asli memungkinkan pemeriksaan ulang bagian visual dan susunan.

## Pemeriksaan per bagian

### p1-b1 — halaman 1

- Jenis: formula.
- Status: preserved.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.

### p1-b2 — halaman 1

- Jenis: paragraph.
- Status: review.
- Sumber dipertahankan setelah penolakan kandidat: ya.
- Tinjauan manual ditandai pengguna: belum.
- Catatan: Error: PROTECTED\_MARKER changed
- Diagnosis teknis (bukan isi terjemahan):
```text
[
  "Error: PROTECTED_MARKER exact detail"
]
```
- Kategori hasil: rejected; dapat dicoba ulang: ya.

### p1-b3 — halaman 1

- Jenis: paragraph.
- Status: edited.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Sumber dikoreksi pengguna; ekstraksi asli tetap tersimpan dan disertakan dalam JURNAL_ASLI.md serta dokumen bilingual.
- Waktu koreksi sumber: fixture.

### p1-b4 — halaman 1

- Jenis: table.
- Status: translated.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
