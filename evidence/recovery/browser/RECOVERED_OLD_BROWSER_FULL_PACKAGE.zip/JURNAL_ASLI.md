# CP20\_VECTOR\_ONLY\_FIGURES — Ekstraksi Sumber

**Berkas sumber:** CP20\_VECTOR\_ONLY\_FIGURES.pdf
**Halaman:** 3
**Bahasa:** en → id
**Status:** Pemrosesan selesai; perlu peninjauan ilmiah 
**Bagian:** 9 diterjemahkan; 0 dipertahankan sengaja; 0 ditolak; 0 gagal; 0 belum diproses. Total 9.
**Rilis eksportir:** cp20-2e4d8ef18eb32385 · 0.20.0.
**Metode:** ekstraksi PDF/OCR dan terjemahan mesin lokal. Tidak ada klaim verifikasi semantik menyeluruh.

**SHA-256 PDF sumber:** e67819ed4cb4f9fafd7c5757c6008fb9da71dd80010c71aa440cc39c551aa224

PDF asli dan aset visual yang tersedia disertakan dalam paket ini.

<!-- halaman: 1 -->

<!-- bagian: p0001-b0001 | halaman: 1 -->

### Vector scientific figure: filled-only-bars

<!-- bagian: p0001-b0002 | halaman: 1 -->

This figure contains measurements whose graphical relationship must be retained.

<!-- bagian: p0001-b0003 | halaman: 1 -->

The source diagram remains essential even when every label is readable.

#### Citra sumber — halaman 1

![Halaman sumber 1](assets/halaman-0001.jpg)


<!-- halaman: 2 -->

<!-- bagian: p0002-b0001 | halaman: 2 -->

### Vector scientific figure: stroked-vector-curve

<!-- bagian: p0002-b0002 | halaman: 2 -->

This figure contains measurements whose graphical relationship must be retained.

<!-- bagian: p0002-b0003 | halaman: 2 -->

The source diagram remains essential even when every label is readable.

#### Citra sumber — halaman 2

![Halaman sumber 2](assets/halaman-0002.jpg)


<!-- halaman: 3 -->

<!-- bagian: p0003-b0001 | halaman: 3 -->

### Vector scientific figure: shading-only-gradient

<!-- bagian: p0003-b0002 | halaman: 3 -->

This figure contains measurements whose graphical relationship must be retained.

<!-- bagian: p0003-b0003 | halaman: 3 -->

The source diagram remains essential even when every label is readable.

#### Citra sumber — halaman 3

![Halaman sumber 3](assets/halaman-0003.jpg)


## Catatan pembacaan

- Ruang browser diprioritaskan untuk dokumen dan hasil Anda. Salinan model unduhan telah dihapus; mesin yang sudah dimuat tetap berjalan pada sesi ini. Offline belum siap. Setelah menutup tab, hubungkan jaringan untuk memuat model kembali.

---

Dibuat dengan Semantik Setara — Academic PDF Translator. Teks sumber, hasil mesin, dan koreksi pengguna dipisahkan secara eksplisit.
