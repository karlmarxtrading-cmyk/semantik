# CATATAN PEMERIKSAAN JURNAL

Berkas: table-edit-fixture.pdf

- Status pekerjaan: complete.
- Halaman terdata: 1/1.
- Bagian sumber: 1.
- Diterjemahkan: 1; dipertahankan sengaja: 0; ditolak: 0; gagal: 0; belum diproses: 0.
- Rilis: cp20-development; hash source build: development.
- SHA-256 PDF sumber: 02b25b90b3a660af5ba3cc2835a41fe20bcf95e0c5ac368b6cabf0ec4026cf02.
- Bagian dengan catatan atau belum diproses: 1.
- Bagian dengan koreksi sumber oleh pengguna: 1.
- Item teks ekstraksi yang terlacak: ? / ?.
- Verifikasi semantik manusia: TIDAK DILAKUKAN OLEH APLIKASI.
- Pemeriksaan otomatis menilai beberapa invariansi struktur, angka, dan identitas ilmiah. Lulus pemeriksaan tidak membuktikan semua makna ilmiah benar.
- Struktur rumus yang didukung diekspor sebagai LaTeX; struktur yang tidak andal diberi label belum terverifikasi dan citra sumber.
- Citra halaman yang berhasil dibaca disertakan dalam paket ZIP. PDF asli memungkinkan pemeriksaan ulang bagian visual dan susunan.

## Pemeriksaan per bagian

### p1-table — halaman 1

- Jenis: table.
- Status: review.
- Sumber dipertahankan setelah penolakan kandidat: tidak.
- Tinjauan manual ditandai pengguna: belum.
- Sumber dikoreksi pengguna; ekstraksi asli tetap tersimpan dan disertakan dalam JURNAL_ASLI.md serta dokumen bilingual.
- Waktu koreksi sumber: 2026-11-13T07:43:38.541Z.
- Catatan: Teks sumber dikoreksi oleh pengguna; cocokkan dengan halaman PDF asli.
- Catatan: Koreksi tabel digunakan sebagai teks utuh; susunan sel asli tetap pada provenance dan citra PDF, bukan hasil koreksi.
- Kategori hasil: translated; dapat dicoba ulang: tidak.
